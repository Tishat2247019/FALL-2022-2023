#include <iostream>
using namespace std;
 int main(){
 int mimo[5], a,b,c;

 a=4;
 mimo[2]=a;
 mimo[a]=3;
 b=mimo[a-2];
 b=mimo[a-2]+2;
 c=mimo[2]+b;
cout<<b;



return 0;}
